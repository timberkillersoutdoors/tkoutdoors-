# Timber Killers Outdoors Website

A complete responsive static website for Timber Killers Outdoors.

## Files
- index.html — main website
- style.css — all styling
- script.js — mobile menu, year, shop notification

## Free publishing
You can publish this site for free with GitHub Pages, Netlify, or Cloudflare Pages.

## Customize
1. Replace the Unsplash image URLs in `style.css` / `index.html` with your own hunting photos.
2. Change the email address in `index.html`.
3. Replace the # social links with your actual Instagram/Facebook/TikTok URLs.
4. Add your real logo later if you want the TK/cypress mark to match your final branding exactly.

The site is intentionally built without a paid framework or backend.
